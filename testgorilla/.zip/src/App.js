import React from 'react'
import { BrowserRouter,Route,Routes} from 'react-router-dom'
import Footer from './Component/Layout/Footer'
import Navbar from './Component/Layout/Navbar'
import Home from './Component/Pages/Home'
import Login from './Component/Pages/Login'
import Pricing from './Component/Pages/Pricing'
import Producttour from './Component/Pages/Producttour'
import Requestdemo from './Component/Pages/Requestdemo'
import Science from './Component/Pages/Science'
import Signup from './Component/Pages/Signup'
import Testlibary from './Component/Pages/Testlibary'

const App = () => {
  return (
    <div>
     <BrowserRouter>
     <Navbar/>
     <Routes>
       <Route extact path='/' element={<Home/>}/>
       <Route extact path='/product' element={<Producttour/>}/>
       <Route extact path='/science' element={<Science/>}/>
       <Route extact path='/test' element={<Testlibary/>}/>
       <Route extact path='/pricing' element={<Pricing/>}/>
       <Route extact path='/login' element={<Login/>}/>
       <Route extact path='/request' element={<Requestdemo/>}/>
       <Route extact path='/signup' element={<Signup/>}/>
     </Routes>
     <Footer/>
     </BrowserRouter>
    </div>
  )
}

export default App
