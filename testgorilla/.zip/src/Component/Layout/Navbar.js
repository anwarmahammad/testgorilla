import React from 'react'
import { Link } from 'react-router-dom'
import './Navbar.css'

const Navbar = () => {
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <Link to='/' className="navbar-brand navk1" >L M S</Link>
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>

  <div className="collapse navbar-collapse" id="navbarSupportedContent">
    <ul className="navbar-nav mr-auto ">
      <li className="nav-item ">
        <Link to='/product' className="nav-link navk2"  >Product tour <span className="sr-only">(current)</span></Link>
      </li>
      <li className="nav-item ">
        <Link to='/science' className="nav-link  navk2" >Science</Link>
      </li>
      <li className="nav-item ">
        <Link to='/test' className="nav-link navk2" >Test library</Link>
      </li><li className="nav-item " >
        <Link to='/pricing' className="nav-link navk2"  >Pricing</Link>
      </li><li className="nav-item ">
        <Link to='/login' className="nav-link navk2" >Login</Link>
      </li>
      <li className="nav-item ">
        <Link to='/request' className="nav-link  navbtn1" >Request Demo</Link>
      </li>
      <Link to='/signup'><button className='btn  navbtn' > Sign up free  <i class="fas fa-angle-right "></i> </button></Link>
    </ul>
   
  </div>
</nav>
    </div>
  )
}

export default Navbar
