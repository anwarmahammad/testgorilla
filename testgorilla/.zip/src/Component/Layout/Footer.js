import React from "react";
const Footer = () => {
  return (
    <div>
      <footer className="footer">
        <div className="row mx-auto">
          <div className="footer-item text-center">
            <img src="\img\LOGO.svg"></img>
            <p>© TestGorilla 2022. All rights reserved.</p>
          </div>
          <div className=" footer-item1 footerHlep">
            <li className="FooterLink"><a href="#">Help Center <i class="fa fa-greater-than arrow"></i></a> </li>
            <li className="FooterLink"><a href="#">Information Candidates <i class="fa fa-greater-than arrow"></i></a></li>
            <li className="FooterLink"><a href="#">For subject matter experts <i class="fa fa-greater-than arrow"></i></a></li>
          </div>
          <div className=" footer-item2 footercareers">
          <li className="FooterLink"><a href="#">Careers <button className="btn btn-light ">Hiring!</button></a></li>
          <li className="FooterLink"><a href="#">Blog  <i class="fa fa-greater-than arrow"></i></a></li>
          <li className="FooterLink"><a href="#">Content  <i class="fa fa-greater-than arrow"></i> </a></li>
          </div>
          <div className="footer-item3 footerlegal">
          <li className="FooterLink"><a href="#">Legal Stuff  <i class="fa fa-greater-than arrow"></i></a></li>
          <li className="FooterLink"><a href="#">Privacy Policy  <i class="fa fa-greater-than arrow"></i></a></li>
          <li className="FooterLink"><a href="#">Site map  <i class="fa fa-greater-than arrow"></i></a></li>
          </div>
          <div className="footer-item4 footerimg2">
              <img src="\img\footer-badges.png.webp" width="100%"></img>
          </div>
        <div className="footer-item5 footericons ">
         <a href="#"><i class="fab fa-facebook-square socialmedia"></i></a>
          <a href="#"> <i class="fab fa-instagram socialmedia"></i></a>
          <a href="#"><i class="fab fa-linkedin socialmedia"></i></a>
          </div>
          </div>
      </footer>
    </div>
  );
};
export default Footer;