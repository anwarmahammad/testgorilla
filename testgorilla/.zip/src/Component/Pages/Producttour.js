import React from 'react'

const Producttour = () => {
  return (
    <div>
      <h1>Product Tour Page</h1>
    </div>
  )
}

export default Producttour
