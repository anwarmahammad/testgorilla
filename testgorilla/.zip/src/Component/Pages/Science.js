import React from 'react'

const Science = () => {
  return (
    <div>
      <h1>Science Page</h1>
    </div>
  )
}

export default Science
