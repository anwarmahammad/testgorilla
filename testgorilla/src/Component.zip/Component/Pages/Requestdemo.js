import React from 'react'
import Talktosales from './Talktosales'
import './Home.css'

const Requestdemo = () => {
  return (
    <div>
      <Talktosales />
    </div>
  )
}

export default Requestdemo
