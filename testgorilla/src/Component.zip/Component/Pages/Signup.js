import React from 'react'
import Award from './Award'
import './Home.css'

const Signup = () => {
  return (
    <div>
      <Award />
    </div>
  )
}

export default Signup
