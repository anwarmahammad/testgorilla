import React from 'react'
import Price from './Price'

const Pricing = () => {
  return (
    <div>
     <Price />
    </div>
  )
}

export default Pricing
