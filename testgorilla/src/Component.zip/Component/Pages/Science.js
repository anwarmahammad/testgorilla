import React from 'react'
import Employer from './Employer'
import './Home.css'



const Science = () => {
  return (
      <div>
<Employer/>

    </div>
  )
}

export default Science
